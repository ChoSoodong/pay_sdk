





/**
    请查看 [支付配置] 文档,进行配置.
 */

#import <Foundation/Foundation.h>


@interface SDPayManager : NSObject

/**
 *  支付状态码
 */
typedef NS_ENUM(NSInteger, PayErrorCode) {
    
    WXERROR_PAYPARAM            = 1001,   //支付参数解析错误
    WXERROR_NOTINSTALL          = 1002,   //未安装微信
    WXERROR_PAY                 = 1003,   //支付失败
    WXCANCEL_PAY                = 1004,   //支付取消
    
    ALIPAYERROR_SCHEME          = 1101,     //scheme错误
    ALIPAYERROR_PAY             = 1102,     //支付错误
    ALIPAYCANCEL_PAY            = 1103      //支付取消
};

/**
 *  获取单例
 */

+(instancetype)sharePayManager;

/**
 *  发起支付宝支付请求
 *
 *  @param pay_param    支付
 *  @param appscheme       应用包名
 *  @param successBlock 成功
 *  @param failBlock    失败
 */
- (void)aliPayWithPayParam:(NSString *)pay_param appScheme:(NSString *)appscheme
                   success:(void (^)(void))successBlock
                   failure:(void (^)(NSInteger err_code))failBlock;

/**
 *  发起微信支付请求
 *
 *  @param pay_param    支付参数
 *  @param successBlock 成功
 *  @param failBlock    失败
 */
- (void)wxPayWithPayParam:(NSDictionary *)pay_param
                  success:(void (^)(void))successBlock
                  failure:(void (^)(NSInteger err_code))failBlock;


/**
 *  回调入口
 *
 *  @param url 回调的链接地址
 *
 *  @return 是否回调
 */
- (BOOL) handleOpenURL:(NSURL *) url;


@end
