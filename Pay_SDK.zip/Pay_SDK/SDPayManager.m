







#import "SDPayManager.h"
#import <AlipaySDK/AlipaySDK.h>
#import "WXApi.h"
@interface SDPayManager()<WXApiDelegate>

@property (nonatomic, copy) void(^paySuccessBlock)();

@property (nonatomic, copy) void(^payErrorBlock)(PayErrorCode err_code);

@end

@implementation SDPayManager

/**
 支付管理类
 */
+ (instancetype)sharePayManager {
    static dispatch_once_t onceToken;
    static SDPayManager *instance;
    dispatch_once(&onceToken, ^{
        instance = [[SDPayManager alloc] init];
    });
    return instance;
}

#pragma mark --------------------------------支付宝------------------------------------
/**
 *  发起支付宝支付请求
 *
 *  @param pay_param    支付
 *  @param appscheme       应用包名
 *  @param successBlock 成功
 *  @param failBlock    失败
 */
- (void)aliPayWithPayParam:(NSString *)pay_param appScheme:(NSString *)appscheme
                   success:(void (^)(void))successBlock
                   failure:(void (^)(NSInteger err_code))failBlock
{
    
    self.paySuccessBlock = successBlock;
    self.payErrorBlock = failBlock;
    
    if (appscheme == nil) {
        failBlock(ALIPAYERROR_SCHEME);
        return;
    }
    
    [[AlipaySDK defaultService] payOrder:pay_param fromScheme:appscheme callback:^(NSDictionary *resultDic) {
        
        [self aliPayResult:resultDic];
        
    }];
}

#pragma mark - 支付宝支付回调处理

- (void)aliPayResult:(NSDictionary *)resultDic
{
    NSInteger resultCode = [resultDic[@"resultStatus"] integerValue];
    
    if (resultDic && [resultDic objectForKey:@"resultStatus"]) {
        switch (resultCode) {
            case 9000:
                //支付成功
                self.paySuccessBlock();
                break;
                
            case 6001:
                //用户点击取消并返回
                self.payErrorBlock(ALIPAYCANCEL_PAY);
                break;
                
            default:
                //剩余都是支付失败
                self.payErrorBlock(ALIPAYERROR_PAY);
                break;
        }
    }

}


#pragma mark --------------------------------微信------------------------------------
- (void)wxPayWithPayParam:(NSDictionary *)pay_param
                  success:(void (^)(void))successBlock
                  failure:(void (^)(NSInteger err_code))failBlock {
    
    self.paySuccessBlock = successBlock;
    self.payErrorBlock = failBlock;
    
    
    if (![[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"weixin://"]])
    {
//        [EJProgressHUD showMessage:@"您尚未安装\"微信App\",请先安装后再返回支付"];
//        failBlock(WXERROR_NOTINSTALL);
        
        return ;
    }
//    if([WXApi isWXAppInstalled] == NO) {
//        [EJProgressHUD showMessage:@"您尚未安装\"微信App\",请先安装后再返回支付"];
//        failBlock(WXERROR_NOTINSTALL);
//        return ;
//    }
    
    if (pay_param == nil || [pay_param isKindOfClass:[NSNull class]] || pay_param.allKeys == 0) {
        failBlock(WXERROR_PAYPARAM);
        return;
    }
    
    NSString *appid     = pay_param[@"appid"];
    NSString *partnerid = pay_param[@"partnerid"];
    NSString *prepayid  = pay_param[@"prepayid"];
    NSString *package   = pay_param[@"packageValue"];
    NSString *noncestr  = pay_param[@"noncestr"];
    NSString *timestamp = pay_param[@"timestamp"];
    NSString *sign      = pay_param[@"sign"];
    
    [WXApi registerApp:appid];
    
    //发起微信支付
    PayReq *req   = [[PayReq alloc] init];
    req.partnerId = partnerid;
    req.prepayId  = prepayid;
    req.nonceStr  = noncestr;
    req.timeStamp = timestamp.intValue;
    req.package   = package;
    req.sign      = sign;
    [WXApi sendReq:req];
}

#pragma mark - 微信支付回调处理

- (void)onResp:(BaseResp *)resp{
    
    if ([resp isKindOfClass:[PayResp class]]) {
        PayResp*response=(PayResp*)resp;  //微信终端返回给第三方的关于支付结果的结构体
        
        switch (response.errCode) {
            case WXSuccess:
                //支付成功
                self.paySuccessBlock();
                break;
                
            case WXErrCodeUserCancel:
                //用户点击取消并返回
                self.payErrorBlock(WXCANCEL_PAY);
                break;
                
            default:
                //剩余都是支付失败
                self.payErrorBlock(WXERROR_PAY);
                break;
        }
    }
}

#pragma mark ---------------------单例类回调--------------------------

- (BOOL) handleOpenURL:(NSURL *) url
{
    if ([url.host isEqualToString:@"safepay"])
    {
        //跳转支付宝钱包进行支付，处理支付结果
        [[AlipaySDK defaultService] processOrderWithPaymentResult:url standbyCallback:^(NSDictionary *resultDic) {
            
            [self aliPayResult:resultDic];
            
        }];
        // 授权跳转支付宝钱包进行支付，处理支付结果
        [[AlipaySDK defaultService] processAuth_V2Result:url standbyCallback:^(NSDictionary *resultDic) {
            // 解析 auth code
            NSString *result = resultDic[@"result"];
            NSString *authCode = nil;
            if (result.length>0) {
                NSArray *resultArr = [result componentsSeparatedByString:@"&"];
                for (NSString *subResult in resultArr) {
                    if (subResult.length > 10 && [subResult hasPrefix:@"auth_code="]) {
                        authCode = [subResult substringFromIndex:10];
                        break;
                    }
                }
            }
        }];
        
        return [url.host isEqualToString:@"safepay"];
    }
    else
    {
        return [WXApi handleOpenURL:url delegate:self];
    }
}
@end
